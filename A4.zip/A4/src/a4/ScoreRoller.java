/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a4;

/**
 *
 * @author meganmurphy
 */
public class ScoreRoller extends DiceRoller{

    /**
     *
     */
    public Dice m_dice;

    /**
     *
     */
    public int sides;
    
    /**
     *
     * @param dice
     */
    public ScoreRoller(Dice dice){
        m_dice = dice;
        sides = 6;
    }

    /**
     *
     * @return
     */
    @Override
    public int DiceRoll(){
        int rolls = m_dice.D(sides) + m_dice.D(sides) + m_dice.D(sides);
        return rolls;
    }
}
