/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a4;

/**
 *
 * @author meganmurphy
 */
public class DnDCharacter {
    public int strength;
    public int dexterity;
    public int constitution;
    public int intelligence;
    public int wisdom;
    public int charisma;
    
    public DnDCharacter(DiceRoller roller){
        strength = roller.DiceRoll();
        dexterity = roller.DiceRoll();
        constitution = roller.DiceRoll();
        intelligence = roller.DiceRoll();
        wisdom = roller.DiceRoll();
        charisma = roller.DiceRoll();
    }

    @Override
    public String toString(){
        String to_string = String.format("class DnDCharacter%nStrength: %d%nDexterity: %d%nConstitution: %d%nIntelligence: %d%nWisdom: %d%nCharisma: %d%n", 
                strength, dexterity, constitution, intelligence, wisdom, charisma);
        return to_string;
    }
}
