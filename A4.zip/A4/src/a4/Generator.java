/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a4;

/**
 * Generator Base Class
 * @author JimR
 */
public abstract class Generator
{
    public abstract int nextInt(int sides);
}
