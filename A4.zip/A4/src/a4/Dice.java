/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a4;

/**
 *
 * @author meganmurphy
 */
public class Dice {
    public Generator generator;
    
    public Dice(Generator gen){
        generator = gen;
    }
    public int D(int sides){
        return generator.nextInt(sides);
    }
}
