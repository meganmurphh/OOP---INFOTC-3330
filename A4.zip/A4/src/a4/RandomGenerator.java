/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a4;

import java.util.Random;

/**
 * RandomGenerator() - gives a random number from 1 to the number
 * of sides on the die.
 * @author JimR
 */
public class RandomGenerator extends Generator
{
    Random m_rand;
    
    public RandomGenerator()
    {
        m_rand = new Random();
    }
    
    @Override
    public int nextInt(int sides)
    {
        return 1 + m_rand.nextInt(sides);
    }
}
