/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a4;
import java.util.Arrays;

/**
 *
 * @author meganmurphy
 */
public class PickBest3of4ScoreRoller extends DiceRoller{

    
    
    /**
     *
     * @param dice
     */
    public PickBest3of4ScoreRoller(Dice dice){
        this.dice = dice;
        this.sides = 6;
    }
   
    /**
     *
     * @return
     */
    @Override
    public int DiceRoll(){
        int[] roll_array = {dice.D(sides), dice.D(sides), dice.D(sides), dice.D(sides)};
        Arrays.sort(roll_array);
        int sorted_array = roll_array[1] + roll_array[2] + roll_array[3];
        return sorted_array;
    }
}
