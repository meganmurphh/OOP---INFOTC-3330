/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beginningoo;
import java.io.*;

/**
 *
 * @author meganmurphy
 */
public class Author {
    private String firstname, lastname;
    
    public Author(String firstName, String lastName){
        this.firstname = firstName;
        this.lastname = lastName;
    }
    public String getname(String getFirstName, String getLastName){
        String name = getFirstName() + getLastName();
        return name;
    }
   
    public String getFirstName(){
        return this.firstname;
    }
    public String getLastName(){
        return this.lastname;
    }
    public void setName(String Newfirstname, String Newlastname){
        this.firstname = Newfirstname;
        this.lastname = Newlastname;
    }
}
