/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beginningoo;

/**
 *
 * @author meganmurphy
 */
public class Book {
    private String title, author;
    private int yearPublished;
    
    public Book(String title, String author, int yearPublished){
        this.title = title;
        this.author = author;
        this.yearPublished = yearPublished;
    }
    public String getInfo(){
        
    }
}
