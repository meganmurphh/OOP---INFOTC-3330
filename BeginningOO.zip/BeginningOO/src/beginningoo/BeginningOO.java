/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package beginningoo;
import beginningoo.BeginningOO.Book;

/**
 *
 * @author meganmurphy
 */
public class BeginningOO {
    
    public static void main(String[] args) {
        String firstname = "Jim ";
        String lastname = "Ries";
        
        Author author = new Author(firstname,lastname);
        System.out.println(author.getName());
        firstname = "Larry ";
        System.out.println(author.getName());
        Author a2 = new Author("Larry ","Ries");
        System.out.println(a2.getName());
        
        Book book = new Book("Some famous title", author, 2022);
        System.out.println(book.getInfo());
        author.setName("Ferd", "Berkle");
        System.out.println(book.getInfo());
        
        Book bookMMM = new Book("The Mythical Man-Month", new Author("Fred", "Brooks"), 1995);
        Book bookCC = new Book("Code Complete", new Author("Steve", "McConnel"), 2004);
        Book bookDragon = new Book("Compilers", new Author("Alfred","Aho"), 1985);
        BookCollection collection = new BookCollection(bookMMM, bookCC, bookDragon);
        collection.PrintBooks();
        BookCollection collection2 = new BookCollection(collection);
        collection.AddBook(book);
        collection.PrintBooks();
        collection2.PrintBooks();
        BookCollection collection3 = new BookCollection();
        collection3.PrintBooks();
        
    }
    public static class Author{
        private String firstName, lastName;
        
        public Author(String firstName, String lastName){
            this.firstName = firstName;
            this.lastName = lastName;
        }
        public void setName(String firstName, String lastName){
            firstName = this.firstName;
            lastName = this.lastName;
        }
        public String getFirstName(String firstName){
            return firstName;
        }
        public String getName(){
            return this.firstName + this.lastName;
        }
    }
    public static class Book{
        private String title;
        private Author author;
        private Integer yearpublished;
        
        public Book(String title, Author author, Integer yearpublished){
            this.title = title;
            this.author = author;
            this.yearpublished = yearpublished;
        }
        public String getInfo(){
            String info = title + ", By " + author.getName() + ", " + yearpublished.toString();
            return info; 
        }
    }
    public static class BookCollection{
        private BookCollection collection;
        
        public BookCollection(BookCollection collection){
            this.collection = collection;
        }
        public BookCollection(Book...books){
        }
        public void AddBook(Book book){
            int i = 0;
            Book[] library = new Book[0]; 
            if(i < library.length && book != null){
                library[i] = book;
                i++;
            }
        }
        public void PrintBooks(){
            System.out.println("********** Books in Collection ***********");
            Book[] library = new Book[3];
            for(var book : library){
                System.out.println(book);
            }
            System.out.println("*******************************************");
        }

    }
          
}

    
    