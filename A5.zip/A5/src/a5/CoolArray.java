/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a5;
import java.util.*;

/**
 *
 * @author meganmurphy: mlm4hb
 */
public class CoolArray implements ICoolArray{
    private Object[] cool_object;
    
    public CoolArray(Object[] object){
        cool_object = object;
    }
   
    public Object Value (int index){
        return cool_object[index];
    }
    
    public void AddValue(Object x){
        int y = cool_object.length;
        Object[] object_z = new Object[y+1];
        for(int i = 0; i < y; i++){
            object_z[i] = cool_object[i]; 
        }
        object_z[y+1] = x;
        cool_object = object_z;
    }
    
    @Override
    public Object[] AsArray(){
        return cool_object;
    }
    
    @Override
    public Object[] AsReversedArray()
    {
        Object[] object_a = cool_object.clone();
        Collections.reverse(Arrays.asList(object_a));
        
        return object_a;
    }
    
    @Override
    public Object[] AsSortedArray(boolean fAscending)
    {
        //int i = 0;
        int n = cool_object.length;
        String[] string = new String[n];
        String temp;
        Object[] object_b = cool_object.clone();
        try
        {
            if(fAscending == true)
            {
                Arrays.sort(object_b);
            }
            else
            {
                Arrays.sort(object_b, Collections.reverseOrder());
            }
        }
        catch(Exception e)
        {
            for(int j = 0; j< cool_object.length; j++)
            {
                 string[j] = cool_object[j].toString();
            }
           for (int x = 0; x < string.length; x++) 
           {
   	   for (int y = x+1; y < string.length; y++) 
           {
                int z = string[y].indexOf(' ', 2);
                int a = string[x].indexOf(' ', 2);
		if ( (string[y].substring(z)).compareTo(string[x].substring(a)) < 0 && fAscending == true) 
                {
                    temp = string[x];
                    string[x] = string[y];
                    string[y] = temp;
		}
                else if ( (string[y].substring(z)).compareTo(string[x].substring(a)) > 0 && fAscending == false) 
                {
                    temp = string[x];
                    string[x] = string[y];
                    string[y] = temp;
                }
            }
        }
    }
        return string;
}
 
    @Override
    public Object ValueAt(int index) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    
}
