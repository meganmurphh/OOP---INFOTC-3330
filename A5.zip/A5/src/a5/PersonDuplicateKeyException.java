/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a5;

/**
 *
 * @author meganmurphy: mlm4hb
 */
public class PersonDuplicateKeyException extends RuntimeException{
   
    public String age;
    
    public PersonDuplicateKeyException(){
        super();
        age = "0";
    }
    
    public PersonDuplicateKeyException(String err){
        super(err);
        age = err;
    }
    
    public String err_message(){
        return("A person with the age of" + age + "already exists within the file.");
    }
    
}
