/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a5;
import java.util.ArrayList;

/**
 *
 * @author meganmurphy: mlm4hb
 */
public class Person {
    public static ArrayList person_list = new ArrayList();
    private String first_name;
    private String last_name;
    private int age;
    
    
    public Person(String f_name, String l_name, int age_x){
        first_name = f_name;
        last_name = l_name;
        age = age_x;
        
        
        if(person_list.contains(age_x)){
            String age_y = Integer.toString(age_x);
            throw new PersonDuplicateKeyException(age_y);
        }      
    }
    
    public Person() throws PersonDuplicateKeyException{
        
    }
    
    public String getFirstName(){
        return this.first_name;
    }
    
    public String getLastName(){
        return this.last_name;
    }
    
    public int getAge(){
        return this.age;
    }
    
    @Override
    public String toString(){
        return String.format("%s %s (%d)", first_name,last_name,age);
    }
    
    public final void DoesKeyExist() throws PersonDuplicateKeyException{
        throw new PersonDuplicateKeyException();
    }
    
    public final void ValidateKey(int age) throws PersonDuplicateKeyException
    {
        if(person_list.contains(age))
        {
            String age_x = Integer.toString(age); 
            throw new PersonDuplicateKeyException(age_x);
        }
    }
    
    
}
